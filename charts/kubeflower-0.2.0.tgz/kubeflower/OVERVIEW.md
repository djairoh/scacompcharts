# DiTEC-WDN FL: Complete System Overview

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                         INFRASTRUCTURE LAYER (Terraform)                        │
│                                                                                 │
│  Kubernetes Cluster                                                             |
│  Managed by: terraform/                                                         │
└─────────────────────────────────────────────────────────────────────────────────┘
                                       ↓
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        STORAGE LAYER (Longhorn)                                 │
│                                                                                 │
│  Longhorn: Kubernetes-native block storage (ReadWriteMany access)               │
│  PVC Size: 10Gi for shared datasets + 5Gi per-pod for checkpoints               │
│  Mounts:                                                                        │
│    - /app/ditec_wdn_dataset/datasets/     ← Shared dataset cache                │
│    - /app/client-state/                   ← Per-pod checkpoints                 │ 
│    - /app/                                ← Final model output                  │
└─────────────────────────────────────────────────────────────────────────────────┘
                                       ↓
┌─────────────────────────────────────────────────────────────────────────────────┐
│                      ORCHESTRATION LAYER (Helm + KubeFlower)                    │
│                                                                                 │
│  Helm Chart: helm/kubeflower/ (defines all Kubernetes manifests)                │
│  Components:                                                                    │
│    1. Init Job: Download datasets from HuggingFace → PVC                        │
│    2. Flower SuperLink (Deployment): FL coordinator                             │
│    3. Flower SuperNodes (StatefulSet): FL clients with stable identity          │
│    4. Training Job: Orchestrates FL rounds via `flwr run kubernetes`            │
│    5. Model Server (Deployment): HTTP endpoint for trained model                │
│    6. Services: Network endpoints for inter-pod communication                   │ 
└─────────────────────────────────────────────────────────────────────────────────┘
                                       ↓
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    FEDERATED LEARNING LAYER (Flower Framework)                  │
│                                                                                 │
│  Data Sources (3 independent water networks, NO data sharing):                  │
│    - kubeflower-client-0: /app/ditec_wdn_dataset/datasets/19PipeSystem_dataset.pt|
│    - kubeflower-client-1: /app/ditec_wdn_dataset/datasets/hanoi_dataset.pt      │
│    - kubeflower-client-2: /app/ditec_wdn_dataset/datasets/Jilin_dataset.pt      │
│                                                                                 │
│  FL Training Process:                                                           │
│    Round 1-10:                                                                  │
│      1. SuperLink broadcasts global model to all clients                       │
│      2. Each client trains locally for 5 epochs using only ITS dataset         │
│      3. Clients upload model updates (weights only, not data)                  │
│      4. SuperLink averages all updates (FedAvg strategy)                       │
│      5. Repeat for next round                                                  │
│                                                                                 │
│  Result: /app/final_model_custom.pt (trained on all 3 datasets without        │
│          centralizing data - privacy preserved!)                              │
└─────────────────────────────────────────────────────────────────────────────────┘
                                       ↓
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        BACKEND API LAYER (Django REST)                          │
│                                                                                 │
│  Endpoint: http://backend:8000                                                 │
│  Functions:                                                                    │
│    - POST   /model/train/   → Triggers Helm upgrade (restarts FL)              │
│    - GET    /model/fetch/latest/ → Fetches latest model from model-service    │
│    - GET    /model/fetch/   → Lists all cached models                         │
│    - GET    /model/fetch/{id}/ → Retrieves specific model                     │
│                                                                                 │
│  Database: SQLite (db.sqlite3)                                                │
│    - CachedModel table: Stores model file references, timestamps               │
│                                                                                 │
│  Flow:                                                                         │
│    1. Backend calls KubeFlower service to trigger training                     │
│    2. Helm deploys fresh FL pipeline                                          │
│    3. Backend polls model-service:8000 for /model.pt                          │
│    4. Downloads completed model, stores path in DB                            │
│    5. Model available to frontend for inference                               │
└─────────────────────────────────────────────────────────────────────────────────┘
                                       ↓
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        FRONTEND LAYER (React/Next.js)                           │
│                                                                                 │
│  Endpoint: http://frontend:3000                                                │
│  Pages:                                                                        │
│    - /train: Trigger model training, set hyperparameters                       │
│    - /monitoring: View training progress (rounds, loss, metrics)               │
│    - /endpoint-test: Test model inference on sample data                       │
│    - /: Home page                                                              │
│                                                                                 │
│  Communication:                                                                │
│    Frontend → Backend (via Next.js API routes)                                │
│    Backend → Backend DB (Django ORM)                                          │
│    Backend → KubeFlower Service (Helm trigger + model fetch)                  │
└─────────────────────────────────────────────────────────────────────────────────┘
                                       ↓
┌─────────────────────────────────────────────────────────────────────────────────┐
│                      MONITORING LAYER (Prometheus)                              │
│                                                                                 │
│  Two-Tier Metrics Architecture:                                                │
│                                                                                 │
│    Tier 1: Flower Apps Export Metrics                                          │
│      - flower/metrics/ module instruments clients/server                        │
│      - prometheus_client library exports metrics via HTTP                       │
│      - Clients listen: 8000, 8001, 8002 (one per ordinal)                      │
│      - Server listens: 8001                                                    │
│      - Metrics: training_loss, eval_loss, rounds_total, MAE                    │
│                                                                                 │
│    Tier 2: Prometheus Scrapes & Django Aggregates                              │
│      - Prometheus servers scrapes all pods every 15 seconds                     │
│      - Stores metrics in time-series database (15-day retention)                │
│      - Django backend queries Prometheus when frontend requests /api/metrics/   │
│      - Backend computes aggregations in-memory:                                │
│        * Average training loss across all clients                              │
│        * Max rounds reached by any client                                       │
│        * Count of active clients                                               │
│        * Per-client metrics breakdown                                          │
│      - Returns aggregated data as JSON to frontend                             │
│                                                                                 │
│  Why No Intermediate Service?                                                  │
│    - Eliminates extra Kubernetes pod (Flask orchestrator)                       │
│    - Backend can compute aggregations on-demand as requests arrive              │
│    - Simpler deployment: fewer services to manage                              │
│    - Still maintains separation: Flower apps → Prometheus → Backend             │
│                                                                                 │
│  Frontend Polling:                                                             │
│    - Polls /api/metrics/ every 30 seconds                                       │
│    - Receives JSON with aggregated data                                        │
│    - Updates charts: training loss, per-client breakdown, active client count   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## Detailed Component Flow

### Phase 1: Infrastructure Setup (Terraform)

```
terraform/ folder contains:
  - config.tf      → Kubernetes cluster configuration
  - network.tf     → Network/VPC setup
  - instance.tf    → VM provisioning
  - image.tf       → Docker image building/pushing
  - outputs.tf     → Cluster endpoints, kubeconfig


### Phase 2: Helm Deployment (Orchestration)

When the backend triggers `helm upgrade --install kubeflower`, Kubernetes executes the deployment in this order:

1. **Init Job** runs first and downloads the three datasets from HuggingFace to the shared persistent volume (only downloads once; subsequent deployments reuse cached data)

2. **Client StatefulSet** creates three pods with stable identities (client-0, client-1, client-2), each mounting the shared datasets and given an ordinal that determines which network topology to train on

3. **Server** pod starts and waits for clients to connect

4. **Training Job** begins orchestrating federated learning rounds once clients are ready

5. **Model Service** pod runs and waits for the final trained model to appear on the shared volume

### Phase 3: Federated Learning Execution

Once all pods are ready, Flower's training orchestration begins with 10 rounds:

**Each round** follows the same pattern:
1. Server broadcasts the current global model (or initial model for round 1) to all clients
2. Clients train locally on their assigned data for 5 epochs and export training metrics
3. Clients send trained weight updates back to the server
4. Server averages all weights using the FedAvg strategy to produce the next global model
5. Loop repeats for the next round

The entire process (10 rounds with training, evaluation, and aggregation) typically takes 10-15 minutes depending on dataset size and network latency. Throughout this time, Prometheus continuously scrapes training metrics from client and server pods, storing them for the frontend dashboard to display.

### Phase 4: Backend Retrieval & Persistence

Once the FL training completes and the final model is saved to the persistent volume, the model-service pod exposes it via HTTP. The Django backend continuously polls this endpoint, and when the model becomes available, it downloads the model binary and stores it in the local SQLite database with metadata (creation timestamp, loss value, version number). This cached model is then available to the frontend for inference testing without re-querying the model-service.

### Phase 5: Frontend UI & Inference

Users interact with the system through three main pages:

- **Training Page** (`/train`): Shows a form to set federated learning hyperparameters (learning rate, epochs per round, number of rounds) and a button to trigger training. User clicks the button, backend starts the FL pipeline, and the form shows status updates.

- **Monitoring Page** (`/monitoring`): Displays real-time training progress with live-updating charts. The page polls the backend's `/api/metrics/` endpoint every 30 seconds to fetch aggregated training metrics (average loss across all clients, per-client breakdowns, current round number, active client count).

- **Endpoint Test Page** (`/endpoint-test`): Once training completes, users can fetch the trained model and run inference on sample water network data. Users upload a JSON file with sensor readings, the backend loads the model, runs predictions, and returns pressure estimates for network nodes.

### Phase 6: Monitoring (Prometheus)

During training, each Flower client and server pod continuously exports real-time metrics (training loss, evaluation loss, rounds completed) via HTTP endpoints. Prometheus scrapes these endpoints automatically every 15 seconds and stores the metrics in a time-series database.

When the frontend requests metrics via `/api/metrics/`, the Django backend directly queries Prometheus using PromQL (Prometheus Query Language) to compute aggregations on-demand: average training loss across all clients, maximum rounds reached, number of active clients, plus per-client breakdowns. The backend returns this aggregated data as JSON, which the frontend receives and displays as live-updating charts showing training progress.

This two-tier approach (Flower → Prometheus → Django) is simpler than having an intermediate aggregation service, since Django can compute the aggregations efficiently whenever requested. The frontend polls every 30 seconds, providing real-time visibility into training without requiring a separate metrics orchestration pod.

---

## Data and Storage Flow

### Input Data (Training)

Three water distribution network datasets from HuggingFace Hub are downloaded once by the init job and cached to a shared persistent volume:

- **19PipeSystem**: 4GB of hourly sensor readings from a 19-node network
- **Hanoi**: 8GB of hourly readings from an 8-node network  
- **Jilin**: 7GB of hourly readings from a larger network

Once cached, each client pod mounts the shared volume and reads only its assigned dataset. Since all clients share the same mounted dataset directory without copies, this is bandwidth-efficient and allows clients to train immediately without waiting for downloads.

### Model Checkpoints (Per-Pod Storage)

During training, each client pod periodically saves model snapshots to its own persistent volume. These checkpoints allow recovery if a pod crashes: when the pod restarts, it reads the last checkpoint and resumes training from that point instead of starting over. Because each pod's checkpoint storage is isolated (client-0 has its own 5GB, client-1 has its own 5GB, etc.), there's no interference between clients.

### Final Model Output (Shared Storage)

After all 10 federated learning rounds complete, the Flower server saves the final aggregated model to the shared persistent volume. A dedicated model-service pod reads this file and exposes it via HTTP endpoint, allowing the backend to download and cache it in the database for future inference requests.

---

## Kubernetes Persistent Volume Configuration

The system uses two types of persistent storage:

**Shared Dataset Cache (10Gi, ReadWriteMany)**: All client pods mount the same persistent volume containing the full DiTEC datasets. This is read once when the init job downloads from HuggingFace, then reused by all clients during training, avoiding redundant network transfers.

**Per-Pod Checkpoints (5Gi each, ReadWriteOnce)**: Each client pod gets its own 5 gigabyte persistent volume for saving training checkpoints at the end of each epoch. If a pod crashes mid-training, it can resume from the last saved checkpoint when Kubernetes restarts it, without losing training progress.

---

## StatefulSet Identity & Data Consistency

Kubernetes StatefulSets guarantee that each pod has a stable, permanent identity:
- **Pod name**: Always `kubeflower-client-0`, `kubeflower-client-1`, or `kubeflower-client-2` (never changes, even after restart)
- **Pod ordinal**: Assigned at creation (0, 1, or 2) and persists even if the pod is deleted and recreated
- **Persistent network name**: Each pod gets a stable DNS name that always routes to it

This stability is critical for federated learning because each client is assigned to a specific water network dataset based on its ordinal:

- **client-0** always trains on the **19PipeSystem** dataset
- **client-1** always trains on the **Hanoi** dataset
- **client-2** always trains on the **Jilin** dataset

If a client pod crashes and Kubernetes restarts it, it gets the exact same name and ordinal, so it automatically loads the same dataset from the persistent volume. This ensures consistent data assignment across training runs and enables recovery from checkpoints.

---

## Complete Request Flow Example

### User clicks "Start Training"

1. **Frontend sends training request**: POST `/gnn/train/`

2. **Backend triggers Helm deployment**: Executes `helm upgrade --install kubeflower` which redeploys the entire FL pipeline

3. **Kubernetes spins up infrastructure**: Init job downloads datasets to persistent volume, three client pods start, server pod starts, all configured with stable identities (client-0, client-1, client-2)

4. **Federated learning begins**: Flower server coordinates 10 rounds of training. In each round:
   - Server broadcasts current global model to all clients
   - Each client trains locally on its assigned dataset (19PipeSystem, Hanoi, or Jilin) for 5 epochs
   - Clients send trained weights back to server (data never leaves client pod)
   - Server averages all weights using FedAvg strategy
   - Next round begins with updated global model

5. **Training completes**: After 10 rounds (~10 minutes), server saves final trained model to persistent volume and metrics are exported to Prometheus

6. **Backend downloads model**: Polls model-service HTTP endpoint, downloads trained model, stores in local database with metadata

7. **Frontend queries progress**: Web dashboard polls `/api/metrics/` every 30 seconds to display live charts of training loss, per-client breakdown, and active client count. Once training completes, model is available for inference testing.

---

## Summary

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Infrastructure** | Terraform | Provision VMs and K8s cluster |
| **Storage** | Longhorn | Persistent volumes (datasets, checkpoints, models) |
| **Orchestration** | Helm + KubeFlower | Deploy and manage FL pipeline |
| **Training** | Flower + PyTorch | Distributed model training across 3 data silos |
| **Models** | GNN (PyTorch Geometric) | Graph attention networks for pressure prediction |
| **Backend** | Django REST | Training trigger, model management, inference |
| **Frontend** | React/Next.js | User interface for training and testing |
| **Monitoring** | Prometheus + Grafana | Training metrics and system health |
| **Pod Management** | StatefulSet | Stable client identity, ordinal-based data assignment |
