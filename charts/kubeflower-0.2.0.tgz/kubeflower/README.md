# KubeFlower Helm Chart

Deploys federated GNN training on Kubernetes. Trains on multiple clients with heterogeneous DiTEC-WDN datasets, aggregates model via FedAvg, and serves the final model for backend inference.

## Architecture

```
DiTEC Datasets (Longhorn PVC)
    ├─ init-job: downloads & partitions data
    ├─ kubeflower-client×N: train locally
    ├─ kubeflower-server: coordinates FedAvg
    ├─ kubeflower-flrun: orchestrates FL rounds → saves final_model_custom.pt
    └─ model-service: HTTP server exposes /model.pt endpoint
```

Backend downloads model from `http://model-service:8000/model.pt`.

## Dataset Distribution

Each client trains on a **different network topology** with **different data**:

```python
CLIENT_NETWORK_MAP = {
    0: "19PipeSystem_4GB_1Y_node",   # → Client 0
    1: "hanoi_8GB_1Y_node",         # → Client 1  
    2: "Jilin_7GB_1Y_node",         # → Client 2
}
```

(See `ditec_wdn_dataset/network_config.py` to add/modify)

## Deploy

### Prerequisites
- Kubernetes cluster with Longhorn storage class
- Helm 3.x
- Docker

### Build Image (from repo root)

```bash
docker build -t ghcr.io/hipsty3/kubeflower:latest .
docker push ghcr.io/hipsty3/kubeflower:latest
```

### Deploy Chart

```bash
helm upgrade --install kubeflower helm/kubeflower \
  --set image.repository=ghcr.io/hipsty3/kubeflower \
  --set image.tag=latest
```

Automatically:
1. Creates PVC for shared storage
2. Runs init-job (downloads datasets)
3. Starts SuperLink + SuperNodes (training)
4. Runs flwr-run job (FL orchestration, saves model)
5. Starts model-service (serves /model.pt)

## Monitor Training

```bash
# All pods
kubectl get pods -l app.kubernetes.io/name=kubeflower

# Logs
kubectl logs -f job/kubeflower-init           # Dataset download
kubectl logs -f job/kubeflower-flrun          # FL training
kubectl logs -f -l component=flower-supernode # Clients
kubectl logs -f -l component=model-serving    # Model HTTP server
```

Training complete when:
```
[INFO] Global model saved to 'final_model_custom.pt'
```

## Verify Model Access

```bash
# Check service is ready
curl http://model-service:8000/health

# Download model (inside cluster)
curl http://model-service:8000/model.pt --output model.pt
```

## Configuration

Edit `helm/kubeflower/values.yaml`:

```yaml
image:
  repository: ghcr.io/hipsty3/kubeflower
  tag: "latest"

flConfig:
  numServerRounds: 10
  numClients: 3          # Must match CLIENT_NETWORK_MAP & client.replicas
  localEpochs: 5
  batchSize: 8
  learningRate: 0.001

client:
  replicas: 3            # Must equal flConfig.numClients

storage:
  persistence:
    storageClass: "longhorn"
    size: 10Gi
```

Override at deploy time:
```bash
helm upgrade kubeflower helm/kubeflower \
  --set flConfig.numServerRounds=20 \
  --set flConfig.numClients=5 \
  --set client.replicas=5
```

When changing `numClients`, add entries to `CLIENT_NETWORK_MAP` first.

## Scale to More Clients

1. Edit `ditec_wdn_dataset/network_config.py` - add to `CLIENT_NETWORK_MAP`
2. Update `helm/kubeflower/values.yaml`:
   ```yaml
   flConfig:
     numClients: 5
   client:
     replicas: 5
   ```
3. Rebuild and redeploy

## Backend Integration

### Trigger Training
```python
from code.backend.model.services import KubeFlowerService
KubeFlowerService.train()  # Redeploys helm chart to retrain
```

### Get Model
```python
KubeFlowerService.get_model()  # Downloads from model-service:8000
```

Endpoints: `POST /model/update` and `GET /model/latest` (in `code/backend/model/`)

## Cleanup

```bash
# Remove Helm release (keeps data)
helm uninstall kubeflower

# Delete PVC and all data
kubectl delete pvc kubeflower-datasets
```

## Troubleshooting

| Issue | Check |
|-------|-------|
| Init-job fails | `kubectl logs job/kubeflower-init` (HuggingFace rate limits?) |
| Clients won't connect | `kubectl logs job/kubeflower-flrun` (server ready?) |
| Model not found | `kubectl logs job/kubeflower-flrun \| grep "final_model"` (training done?) |
| model-service errors | `kubectl logs -l component=model-serving` |

## Components

| Component | Resource | Port |
|-----------|----------|------|
| kubeflower-server | Deployment | 9093 (Exec API) |
| kubeflower-client | Deployment (replicas: N) | - |
| kubeflower-init | Job | - |
| kubeflower-flrun | Job | - |
| model-service | Deployment | 8000 |
| kubeflower-datasets | PVC | - |
