# KubeFlower Helm Chart

Deploys federated GNN training on Kubernetes using Flower. Each client trains on its own dataset (per-pod storage), the server aggregates via FedAvg, and the final model is persisted for later use.

---

## Architecture

```
Stateful Clients (per-pod PVCs)
    ├─ kubeflower-client-0 → dataset_0 (PVC)
    ├─ kubeflower-client-1 → dataset_1 (PVC)
    ├─ kubeflower-client-2 → dataset_2 (PVC)

Server (Deployment)
    ├─ kubeflower-server
    ├─ aggregates via FedAvg
    └─ saves final model → model-output PVC

FL Orchestration
    └─ kubeflower-flrun (Job)
```

### Key design decisions

- **One PVC per client** (via StatefulSet)
- **InitContainer per client** prepares dataset
- **Server has its own PVC for model output**
- No shared RWX volume (avoids Longhorn NFS issues)
- No init-job
- No model-service (yet)

---

## Dataset Distribution

Each client trains on a **different network topology**:

```python
CLIENT_NETWORK_MAP = {
    0: "19PipeSystem_4GB_1Y_node",
    1: "hanoi_8GB_1Y_node",
    2: "Jilin_7GB_1Y_node",
}
```

Mapping is based on:

```
CLIENT_ID = StatefulSet pod ordinal (0,1,2,...)
```

---

## Deploy

### Prerequisites

- Kubernetes cluster
- Longhorn (or any CSI storage class)
- Helm 3.x
- Docker

---

### Build Image

```bash
docker build -t ghcr.io/hipsty3/kubeflower:latest .
docker push ghcr.io/hipsty3/kubeflower:latest
```

---

### Deploy

```bash
helm upgrade --install kubeflower helm/kubeflower \
  --set image.repository=ghcr.io/hipsty3/kubeflower \
  --set image.tag=latest
```

---

### What happens automatically

1. StatefulSet creates **N clients**
2. Each client:
    - gets its own PVC
    - runs initContainer → prepares dataset
3. Server starts
4. `flwr run` Job orchestrates training
5. Server saves model to `/app/model-output`

---

## Monitor Training

```bash
# All pods
kubectl get pods -l app.kubernetes.io/name=kubeflower

# Server logs
kubectl logs -f deploy/kubeflower-server

# Clients
kubectl logs -f -l component=flower-supernode

# FL orchestration
kubectl logs -f job/kubeflower-flrun
```

---

## Verify Model Output

```bash
kubectl exec -it deploy/kubeflower-server -- ls -l /app/model-output
```

Expected:

```
final_model_custom.pt
fl_metadata.json
```

---

## Configuration

Edit `values.yaml`:

```yaml
image:
  repository: ghcr.io/hipsty3/kubeflower
  tag: "latest"

flConfig:
  numServerRounds: 10
  numClients: 3

client:
  replicas: 3

storage:
  persistence:
    storageClass: "longhorn"
    accessMode: ReadWriteOnce
    size: 2Gi
```

---

## Scaling Clients

1. Update:

```python
CLIENT_NETWORK_MAP
```

1. Update Helm values:

```yaml
flConfig:
  numClients: 5
client:
  replicas: 5
```

1. Redeploy

---

## Model Access (Current)

Right now, the model is stored on the server PVC:

```
/app/model-output/final_model_custom.pt
```

To retrieve it:

```bash
kubectl cp \
  deploy/kubeflower-server:/app/model-output/final_model_custom.pt \
  ./model.pt
```

---

## Future Improvement (Recommended)

You can later add:

- HTTP model serving (FastAPI or simple server)
- object storage (S3 / MinIO)
- versioned models

---

## Cleanup

```bash
helm uninstall kubeflower
```

Delete all PVCs:

```bash
kubectl delete pvc -l app.kubernetes.io/name=kubeflower
```

---

## Troubleshooting

| Issue | Check |
| --- | --- |
| Client stuck | `kubectl logs <client-pod>` |
| Dataset missing | initContainer logs |
| FL not starting | `kubectl logs job/kubeflower-flrun` |
| Model missing | server logs |

---

## Components

| Component | Resource |
| --- | --- |
| kubeflower-server | Deployment |
| kubeflower-client | StatefulSet |
| kubeflower-flrun | Job |
| client datasets | per-pod PVC |
| model-output | PVC |