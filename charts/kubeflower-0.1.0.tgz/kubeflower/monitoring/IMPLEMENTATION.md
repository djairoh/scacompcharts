# Prometheus Metrics Implementation for KubeFlower

## Overview

This document describes the simplified two-tier metrics architecture that replaced the original three-tier design (which had an unnecessary Flask orchestrator).

```
Flower Apps (ports: 8000±ordinal for clients, 8001 for server)
    ↓ [HTTP metrics endpoints - prometheus-client library]
Prometheus Server (9090)
    ↓ [PromQL API queries]
Django Backend (API endpoint: /api/metrics/)
    ↓ [Answers PromQL queries, computes aggregations in-memory]
Frontend Dashboard (React - polls every 30 seconds)
```

## How It Works

### Tier 1: Flower Apps Export Metrics
Each Flower client and server pod runs a `prometheus-client` metrics exporter on an HTTP port:
- **Clients**: Individual ports per pod (8000 + ordinal), so client-0 is 8000, client-1 is 8001, client-2 is 8002
- **Server**: Fixed port 8001
- **Metrics exported**: 
  - `flower_client_train_loss` - Training loss per client epoch
  - `flower_client_eval_loss` - Evaluation loss per client
  - `flower_client_rounds_total` - Counter of rounds completed
  - `flower_server_current_round` - Server's current round number
  - `flower_server_active_clients` - Count of connected clients
  - Plus additional metrics like MAE, learning rates, etc.

These metrics are formatted according to Prometheus exposition format (simple text-based key-value pairs) and scraped by Prometheus regularly. The Flower apps don't need to know anything about how metrics are used downstream—they just export via HTTP.

### Tier 2: Prometheus Collects & Django Backend Aggregates
Prometheus is deployed as a Kubernetes pod that:
1. Automatically discovers all Flower pods via Kubernetes labels
2. Scrapes their HTTP metrics endpoints every 15 seconds
3. Stores metrics in a time-series database (15-day retention)

When the frontend requests metrics, the flow is:
1. Frontend calls `GET /api/metrics/`
2. Django backend receives the request
3. Backend queries Prometheus API with PromQL queries:
   - `avg(flower_client_train_loss)` → returns average loss across all clients
   - `max(flower_client_rounds_total)` → returns highest round number seen
   - `count(count by (pod_name) (flower_client_train_loss))` → counts active clients
4. Backend computes these aggregations on-demand (no intermediate cache)
5. Returns structured JSON to frontend

This eliminates the need for a separate Flask service that would continuously poll and cache aggregations—the aggregation happens when requested, computed efficiently from Prometheus's time-series database.

## Deployment

### Prerequisites
- Flower metrics module installed in client/server apps
- Prometheus Kubernetes deployment with pod discovery configured
- Django backend with updated metrics views

### No Flask Orchestrator Needed
The original implementation had:
```
Flower → Prometheus → Flask Orchestrator → Django → Frontend
```

The new implementation is:
```
Flower → Prometheus → Django → Frontend
```

This removes one pod, one service, and one Helm chart template without losing functionality.

## Key Files

| File | Purpose |
|------|---------|
| `flower/metrics/client_metrics.py` | Client metric exports |
| `flower/metrics/server_metrics.py` | Server metric exports |
| `helm/kubeflower/monitoring/prometheus/*` | Prometheus deployment |
| `code/backend/metrics/views.py` | Backend endpoint + PromQL queries + aggregation logic |
| `code/backend/server/urls.py` | Route `/api/metrics/` |

## Testing

```bash
# 1. Check if Flower apps are exporting metrics
kubectl exec -it kubeflower-client-0 -- curl localhost:8000/metrics | grep flower_client

# 2. Query Prometheus directly
kubectl port-forward svc/prometheus 9090:9090
curl 'http://localhost:9090/api/v1/query?query=avg(flower_client_train_loss)'

# 3. Check backend endpoint
curl 'http://backend:8000/api/metrics/' | jq '.client_metrics'

# 4. Check raw Prometheus format from backend
curl 'http://backend:8000/api/metrics/?format=prometheus' | grep flower_client
```

## Environment Variables

| Variable | Default |
|----------|---------|
| `PROMETHEUS_URL` | `http://prometheus:9090` |

The `METRICS_ORCHESTRATOR_URL` variable is no longer needed since the backend queries Prometheus directly.

## Metrics Available

The backend's `/api/metrics/` endpoint returns JSON with the following structure:

```json
{
  "client_metrics": {
    "avg_train_loss": 0.512,
    "avg_eval_loss": 0.505,
    "max_rounds": 5,
    "active_clients": 3,
    "per_client": [
      {
        "pod_name": "kubeflower-client-0",
        "ordinal": "0",
        "train_loss": 0.523,
        "eval_loss": 0.510,
        "rounds": 5
      },
      ...
    ]
  },
  "server_metrics": {
    "current_round": 5,
    "active_clients": 3,
    "train_loss": 0.512,
    "eval_loss": 0.505
  }
}
```

## Architecture Decision: Why No Intermediate Service?

**Original Three-Tier Approach:**
- Pros: Decouples Prometheus from backend, allows reuse of metrics service
- Cons: Extra pod to manage, extra network hop, continuous polling overhead on Prometheus

**Simplified Two-Tier Approach:**
- Pros: Fewer moving parts, queries only when needed, Django's HTTP client handles retries/timeouts well
- Cons: Django/Prometheus network latency per request (but 30-second polling interval hides this)
- Verdict: For non-real-time monitoring (30-second cadence), on-demand aggregation is simpler and sufficient


