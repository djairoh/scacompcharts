# KubeFlower Monitoring

Prometheus + Grafana monitoring stack for the KubeFlower federated learning system, together with a Next.js frontend integration that displays live metrics.

## Architecture

```
KubeFlower pods  ──push──►  Pushgateway :9091
                                │
                     Prometheus :9090  ◄──scrape──
                                │
                     Grafana :3001  ◄──datasource──
                                │
              Next.js /api/metrics  ◄──proxy──
                                │
              /monitoring page  ◄──fetch──
```

| Component | Port | Purpose |
|-----------|------|---------|
| Prometheus | 9090 | Scrapes and stores time-series metrics |
| Grafana | 3001 | Visualises metrics; dashboard auto-provisioned |
| Pushgateway | 9091 | Receives per-round FL metrics pushed by the ServerApp |

## Quick Start (local development)

```bash
cd helm/kubeflower/monitoring
docker compose up --build
```

- Prometheus UI → http://localhost:9090  
- Grafana UI    → http://localhost:3001  (admin / admin)  
- Pushgateway   → http://localhost:9091  

The Next.js frontend reads `PROMETHEUS_URL` (server-side) and `NEXT_PUBLIC_GRAFANA_URL` (client-side). Add these to `frontend/.env.local`:

```env
PROMETHEUS_URL=http://localhost:9090
NEXT_PUBLIC_GRAFANA_URL=http://localhost:3001
```

Then browse to http://localhost:3000/monitoring.

## Pushing FL Metrics from the ServerApp

After each federated round, push metrics to the Pushgateway using the `prometheus_client` library.  
Add this helper to `flower/flower_server_app.py`:

```python
from prometheus_client import CollectorRegistry, Gauge, push_to_gateway

PUSHGATEWAY = os.getenv("PUSHGATEWAY_URL", "localhost:9091")

def push_round_metrics(round_num: int, train_loss: float, eval_loss: float,
                        train_mae: float, eval_mae: float, num_clients: int) -> None:
    registry = CollectorRegistry()
    Gauge("flower_train_loss",     "Training loss",      registry=registry).set(train_loss)
    Gauge("flower_eval_loss",      "Evaluation loss",    registry=registry).set(eval_loss)
    Gauge("flower_train_mae",      "Training MAE",       registry=registry).set(train_mae)
    Gauge("flower_eval_mae",       "Evaluation MAE",     registry=registry).set(eval_mae)
    Gauge("flower_rounds_total",   "Rounds completed",   registry=registry).set(round_num)
    Gauge("flower_active_clients", "Active client count",registry=registry).set(num_clients)
    push_to_gateway(PUSHGATEWAY, job="kubeflower", registry=registry)
```

Call `push_round_metrics(...)` inside the `on_round_end` hook (or after each round in `strategy.start`).

## Grafana Dashboard

The provisioned dashboard (`grafana/dashboards/kubeflower.json`) contains:

- **Rounds Completed** – stat panel  
- **Active Clients** – stat panel  
- **Latest Train / Eval Loss** – stat panels with colour thresholds  
- **Training Loss per Round** – time-series  
- **Evaluation Loss per Round** – time-series  
- **Training / Eval MAE per Round** – time-series  

All panels use Prometheus as the data source (uid `prometheus`) and refresh every 30 s.

## Deploying in Kubernetes

For in-cluster deployment, uncomment the `kubernetes-pods` scrape job in `prometheus.yml` and annotate the KubeFlower pods:

```yaml
annotations:
  prometheus.io/scrape: "true"
  prometheus.io/port: "9091"   # adjust to your metrics port
```

Pass `PUSHGATEWAY_URL=kubeflower-pushgateway:9091` to the ServerApp container through the Helm values.

## File Structure

```
monitoring/
├── Dockerfile.prometheus          # Prometheus image (bakes in prometheus.yml)
├── Dockerfile.grafana             # Grafana image (bakes in provisioning + dashboard)
├── prometheus.yml                 # Scrape config (pushgateway + optional k8s SD)
├── compose.yaml                   # Run the full stack locally
├── grafana/
│   ├── provisioning/
│   │   ├── datasources/
│   │   │   └── prometheus.yaml    # Auto-wires Prometheus datasource
│   │   └── dashboards/
│   │       └── dashboards.yaml    # Auto-loads dashboards from /grafana/dashboards
│   └── dashboards/
│       └── kubeflower.json        # Pre-built KubeFlower dashboard
└── README.md
```
